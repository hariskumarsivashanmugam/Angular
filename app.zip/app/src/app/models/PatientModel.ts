export interface PatientModel{
        patientHeight: Number,
        patientBloodGroup: String,
        patientWeight: Number,
        fkRoleId : 2,
        userUsername : String,
        userPassword : String,
        userEmail : String,
        userPhonenumber : String,
        userFirstname : String,
        userLastname : String,
        userAge : Number,
        userCity : String,
        userState : String,
        userStreet : String,
        pkPatientId: Number
}