import {UserModel} from './UserModel';
export class DoctorModel{
    constructor(public DoctorId: Number,
        public DoctorExperience: Number,
        public Speciality: String,
        public UserId: Number,
        public User : UserModel){
        }
}