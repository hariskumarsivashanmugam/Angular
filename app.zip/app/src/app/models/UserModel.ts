export class UserModel{
    constructor(public Userid : Number,
        public Username : String,
        public Password : String,
        public Email : String,
        public PhoneNumber : Number,
        public Firstname : String,
        public LastName : String,
        public Age : Number,
        public City : String,
        public State : String,
        public Street : String,
        public RoleId : Number){

    }
}