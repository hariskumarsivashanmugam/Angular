import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse , HttpHeaders, HttpErrorResponse} from '@angular/common/http'
import { DoctorModel } from './models/DoctorModel';
import { UserModel } from './models/UserModel';
import { PatientModel } from './models/PatientModel';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  private apiUrl = "http://localhost:8080";
  data: any = {};
  constructor(private httpClient: HttpClient) {
   }
   
  getAllPatients(){
     return this.httpClient.get('http://localhost:8080/readAllPatients');
  }

  getPatient(id){
    return this.httpClient.get(`${this.apiUrl}/readPatient/${id}`);
  }

  createPatient(patient : PatientModel){
    console.log(patient);
    return this.httpClient.post('http://localhost:8080/create',patient);
  }

  deletePatients(id : Number){
    return this.httpClient.delete('http://localhost:8080/delete/${id}');
  }

  updatePatients(patient : PatientModel){
    return this.httpClient.put('http://localhost:8080/update',patient);
  }
  deletePatientsFrom(id: number):Observable<any>{
    return this.httpClient.delete(`http://localhost:8080/delete/${id}`);
  }
  
}

