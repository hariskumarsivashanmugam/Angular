import { Component, OnInit, Input} from '@angular/core';
import { Observable } from 'rxjs';
import { UserService } from '../user.service';
import { PatientModel } from '../models/PatientModel';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  allPatients;
  patients : String [];
  details : String [];
  userUsername: String;
  userPassword: String;
  userEmail: String;
  userPhonenumber: String;
  userFirstname: String;
  userLastname: String;
  userAge: Number;
  userCity: String;
  userState: String;
  userStreet: String;
  patientHeight: Number;
  patientWeight: Number;
  patientBloodGroup: String;

  constructor(private userService : UserService) {
   }
  // doctors = [
  //   {name:"HarisKumar",
  //    specialist : "Surgeon",
    
  // },
  //   {name:"Nirmal",specialist : "Ortho",}
  // ]
   onCreatePressed(){
     console.log("createPressed");
     let patient : PatientModel ={
      userUsername:this.userUsername,
      userPassword:this.userPassword,
      userEmail:this.userEmail,
      userPhonenumber:this.userPhonenumber,
      userFirstname:this.userFirstname,
      userLastname:this.userLastname,
      userAge:this.userAge,
      userCity:this.userCity,
      userState:this.userState,
      userStreet:this.userStreet,
      patientHeight:this.patientHeight,
      patientWeight:this.patientWeight,
      patientBloodGroup:this.patientBloodGroup,
      pkPatientId : null,
      fkRoleId:2
     };
     console.log(patient);
     this.userService.createPatient(patient).subscribe((res)=>{
       console.log(res);
     })
   }
  ngOnInit() {
    this.userService.getAllPatients().subscribe((res) => {
      this.allPatients = res;
      this.patients = this.allPatients.data as String[];
      // let something = Object.keys(this.patients);
      // for(const prop of something){
      //   this.details.push(this.patients[prop]);
      // }
      // console.log(this.details);
      console.log(this.patients);
      // console.log(this.allPatients);
      
      // console.log("Helo");
    }
    )}

}
