import { Component, OnInit, Input } from '@angular/core';
import { UserService } from '../user.service';
import { PatientModel } from '../models/PatientModel';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-doctorcard',
  templateUrl: './doctorcard.component.html',
  styleUrls: ['./doctorcard.component.css']
})
export class DoctorcardComponent implements OnInit {
  // @Input() allPatients=[];
  // @Input() patients;
  // @Input() details=[];
  patientHeight;
  patientWeight;
  patientBloodGroup;
  allPatients;
  patients : String [];
  details : String [];
  constructor(public userService : UserService) { 
  }
  onUpdatePressed(patient){
    console.log(patient);
    let patients : PatientModel = {
      userUsername:patient.userUsername,
      userPassword:patient.userPassword,
      userEmail:patient.userEmail,
      userPhonenumber:patient.userPhonenumber,
      userFirstname:patient.userFirstname,
      userLastname:patient.userLastname,
      userAge:patient.userAge,
      userCity:patient.userCity,
      userState:patient.userState,
      userStreet:patient.userStreet,
      patientHeight:this.patientHeight,
      patientBloodGroup:this.patientWeight,
      patientWeight:this.patientBloodGroup,
      pkPatientId : patient.pkPatientId,
      fkRoleId:2
    }
    console.log(patients);
    this.userService.updatePatients(patients).subscribe((res)=>{
      console.log(res);
    })
  }

  onDeletePressed(patient){
    console.log(patient.pkPatientId);
    this.userService.deletePatientsFrom(patient.pkPatientId).subscribe((res)=>{
      console.log(res);
    })
    this.patients.splice(this.patients.indexOf(patient),1);
  }
  ngOnInit() {
    this.userService.getAllPatients().subscribe((res) => {
      this.allPatients = res;
      this.patients = this.allPatients.data as String[];

});
}
}
