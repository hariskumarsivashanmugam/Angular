import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patientcard',
  templateUrl: './patientcard.component.html',
  styleUrls: ['./patientcard.component.css']
})
export class PatientcardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
