import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  UserEmail;
  userPassword

  constructor(private service : UserService,private router:Router) { }

  ngOnInit() {
  }
  onLogin = ()=>{
    console.log(this.UserEmail);
    console.log(this.userPassword);
    // this.service.setEmail(this.UserEmail);
    // this.service.setPassword(this.userPassword);
    this.router.navigate(['dashboard']);
  }


}
